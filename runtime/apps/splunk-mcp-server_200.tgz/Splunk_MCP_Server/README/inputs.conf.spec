[mcp_heartbeat]
* Input-kind level settings for the mcp_heartbeat modular input.

python.version = python3
* The Python interpreter used to run the modular input script.

python.required = <comma-separated versions>
* The Python interpreter versions this modular input is validated against.

[mcp_heartbeat://<name>]
* Periodically pings the local /services/mcp endpoint to keep the persistent
* MCP server process warm and avoid cold-start failures after idle periods.

interval = <integer>
* How often, in seconds, to ping /services/mcp.
* Defaults to 30.
